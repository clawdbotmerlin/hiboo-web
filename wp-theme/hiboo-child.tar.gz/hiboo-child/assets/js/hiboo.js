/**
 * Hiboo Baby Skincare — Main JS
 * Scroll animations, mobile menu, product card clicks,
 * filter/sort pills, FAQ accordion, Instagram feed.
 */

(function () {
  'use strict';

  /* ── Scroll Animations (IntersectionObserver) ── */
  var animObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.08 });

  var animSelectors = '.product-card, .why-card, .testi-card, .concern-card, .sci-feat, .trust-item, .cert-card, .team-card, .ing-card, .blog-card, .freefrom-card, .stat-item';
  document.querySelectorAll(animSelectors).forEach(function (el, i) {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease ' + (i * 0.06) + 's, transform 0.6s ease ' + (i * 0.06) + 's';
    animObserver.observe(el);
  });

  /* ── Mobile Menu Toggle ── */
  var menuBtn = document.querySelector('.mobile-menu-btn');
  var navLinks = document.querySelector('.nav-links');

  if (menuBtn && navLinks) {
    menuBtn.addEventListener('click', function () {
      var isOpen = navLinks.classList.toggle('mobile-open');
      var spans = menuBtn.querySelectorAll('span');
      if (isOpen) {
        navLinks.style.display = 'flex';
        navLinks.style.flexDirection = 'column';
        navLinks.style.position = 'absolute';
        navLinks.style.top = '100%';
        navLinks.style.left = '0';
        navLinks.style.right = '0';
        navLinks.style.background = 'var(--hb-cream)';
        navLinks.style.padding = '20px';
        navLinks.style.gap = '16px';
        navLinks.style.borderBottom = '1px solid rgba(0,0,0,0.06)';
        navLinks.style.boxShadow = '0 8px 24px rgba(0,0,0,0.06)';
        navLinks.style.zIndex = '99';
        // Animate hamburger to X
        if (spans.length >= 3) {
          spans[0].style.transform = 'translateY(7px) rotate(45deg)';
          spans[1].style.opacity = '0';
          spans[2].style.transform = 'translateY(-7px) rotate(-45deg)';
        }
      } else {
        navLinks.style.display = '';
        navLinks.style.flexDirection = '';
        navLinks.style.position = '';
        navLinks.style.top = '';
        navLinks.style.left = '';
        navLinks.style.right = '';
        navLinks.style.background = '';
        navLinks.style.padding = '';
        navLinks.style.gap = '';
        navLinks.style.borderBottom = '';
        navLinks.style.boxShadow = '';
        navLinks.style.zIndex = '';
        if (spans.length >= 3) {
          spans[0].style.transform = '';
          spans[1].style.opacity = '';
          spans[2].style.transform = '';
        }
      }
    });
  }

  /* ── Product Card Click Handler (data-href) ── */
  document.querySelectorAll('.product-card[data-href]').forEach(function (card) {
    card.style.cursor = 'pointer';
    card.addEventListener('click', function (e) {
      if (e.target.closest('.product-quick-links')) return;
      window.location.href = this.dataset.href;
    });
  });

  /* ── Filter Pills (Products Page) ── */
  document.querySelectorAll('.filter-pill').forEach(function (pill) {
    pill.addEventListener('click', function () {
      document.querySelectorAll('.filter-pill').forEach(function (p) { p.classList.remove('active'); });
      pill.classList.add('active');
      var filter = pill.dataset.filter;
      var cards = document.querySelectorAll('.products-listing .product-card');
      var visible = 0;
      cards.forEach(function (card) {
        if (filter === 'all' || card.dataset.category === filter) {
          card.style.display = '';
          visible++;
        } else {
          card.style.display = 'none';
        }
      });
      var countEl = document.querySelector('.result-count strong');
      if (countEl) countEl.textContent = visible;
    });
  });

  /* ── Sort Pills (Products Page) ── */
  document.querySelectorAll('.sort-pill').forEach(function (pill) {
    pill.addEventListener('click', function () {
      document.querySelectorAll('.sort-pill').forEach(function (p) { p.classList.remove('active'); });
      pill.classList.add('active');
      var sort = pill.dataset.sort;
      var grid = document.querySelector('.products-listing .products-grid');
      if (!grid) return;
      var cards = Array.from(grid.querySelectorAll('.product-card'));
      cards.sort(function (a, b) {
        switch (sort) {
          case 'popular': return parseInt(b.dataset.sold || 0) - parseInt(a.dataset.sold || 0);
          case 'newest': return (b.dataset.date || '').localeCompare(a.dataset.date || '');
          case 'price-low': return parseInt(a.dataset.price || 0) - parseInt(b.dataset.price || 0);
          case 'price-high': return parseInt(b.dataset.price || 0) - parseInt(a.dataset.price || 0);
          default: return 0;
        }
      });
      cards.forEach(function (card) { grid.appendChild(card); });
    });
  });

  /* ── FAQ Accordion ── */
  document.querySelectorAll('.faq-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = this.closest('.faq-item');
      var isActive = item.classList.contains('active');
      // Close all
      document.querySelectorAll('.faq-item').forEach(function (fi) { fi.classList.remove('active'); });
      // Toggle current
      if (!isActive) {
        item.classList.add('active');
      }
    });
  });

  /* ── Instagram Feed Fallback ── */
  var instaGrid = document.getElementById('instaGrid');
  if (instaGrid) {
    var igLink = 'https://www.instagram.com/hiboo.baby/';
    // Determine base URL for images — try to find theme URI from existing img tags
    var existingImg = document.querySelector('.hero-product-img, .nav-logo img');
    var themeBase = '';
    if (existingImg && existingImg.src) {
      var match = existingImg.src.match(/^(.*\/assets\/images)\//);
      if (match) themeBase = match[1];
    }

    function renderFallbackGrid() {
      var items = [
        { img: '/products/mochi-serum-100ml.png', bg: '#E8F4FC' },
        { img: '/products/balm-15g.png', bg: '#FFF3EA' },
        { img: '/products/zzz-cream-30g.png', bg: '#EDE7F6' },
        { img: '/products/mochi-sunscreen-30ml.png', bg: '#E8F5E4' },
        { img: '/products/mochi-face-15ml.png', bg: '#FFF3DC' },
        { img: '/products/balm-5g.png', bg: '#F9E4D4' },
        { img: '/products/mochi-serum-50ml.png', bg: '#D5EDFA' },
        { img: '/products/zzz-cream-15g.png', bg: '#FFF1E6' },
        { img: '/products/balm-box-15g.png', bg: '#E8F5E4' },
        { img: '/products/all-products.png', bg: '#EDE7F6' }
      ];

      instaGrid.innerHTML = '';
      items.forEach(function (item) {
        var tile = document.createElement('div');
        tile.className = 'insta-tile';
        tile.innerHTML =
          '<a href="' + igLink + '" target="_blank" rel="noopener">' +
            '<div style="width:100%;height:100%;background:' + item.bg + ';display:flex;align-items:center;justify-content:center;padding:16px;">' +
              '<img src="' + themeBase + item.img + '" alt="Hiboo Baby Instagram" loading="lazy" style="max-height:85%;max-width:85%;object-fit:contain;filter:drop-shadow(0 4px 12px rgba(0,0,0,0.08));">' +
            '</div>' +
            '<div class="insta-overlay">' +
              '<span class="insta-overlay-stat" style="font-size:13px;">Lihat di Instagram</span>' +
            '</div>' +
          '</a>';
        instaGrid.appendChild(tile);
      });
    }

    // Load feed when section is visible
    var feedObserver = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) {
        renderFallbackGrid();
        feedObserver.disconnect();
      }
    }, { threshold: 0.1 });

    var instaSection = document.querySelector('.insta-section');
    if (instaSection) {
      feedObserver.observe(instaSection);
    } else {
      // If we're on front-page and section exists
      renderFallbackGrid();
    }
  }

})();
